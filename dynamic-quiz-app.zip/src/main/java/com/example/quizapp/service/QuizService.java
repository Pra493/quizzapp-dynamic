
package com.example.quizapp.service;

import com.example.quizapp.model.Question;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class QuizService {

    // return dynamic list of questions (static-coded here for demo)
    public List<Question> getQuestions() {
        List<Question> list = new ArrayList<>();
        list.add(new Question(1, "What is Java?", new String[]{"Programming Language","Operating System","IDE","Database"}, "Programming Language"));
        list.add(new Question(2, "Which keyword is used to inherit a class in Java?", new String[]{"super","this","extends","implements"}, "extends"));
        list.add(new Question(3, "What does HTML stand for?", new String[]{"Hyperlinks and Text Markup","Hyper Text Markup Language","Home Tool Markup","Hyper Tool Multi Language"}, "Hyper Text Markup Language"));
        list.add(new Question(4, "Which CSS property controls text size?", new String[]{"font-style","text-size","font-size","text-style"}, "font-size"));
        return list;
    }

    public int calculateScore(List<Question> questions, java.util.Map<Integer, String> answers) {
        int score = 0;
        for (Question q : questions) {
            String ans = answers.get(q.getId());
            if (ans != null && ans.equals(q.getCorrectAnswer())) {
                score++;
            }
        }
        return score;
    }
}
