
package com.example.quizapp.controller;

import com.example.quizapp.model.Question;
import com.example.quizapp.service.QuizService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class QuizController {

    private final QuizService quizService;

    public QuizController(QuizService quizService) {
        this.quizService = quizService;
    }

    @GetMapping("/quiz")
    public String showQuiz(Model model, HttpSession session) {
        if (session.getAttribute("user") == null) return "redirect:/";
        List<Question> questions = quizService.getQuestions();
        model.addAttribute("questions", questions);
        model.addAttribute("total", questions.size());
        return "quiz";
    }

    @PostMapping("/submit")
    public String submit(@RequestParam Map<String,String> params, Model model, HttpSession session) {
        if (session.getAttribute("user") == null) return "redirect:/";
        List<Question> questions = quizService.getQuestions();
        Map<Integer, String> answers = new HashMap<>();
        for (Question q : questions) {
            String key = "q" + q.getId();
            if (params.containsKey(key)) {
                answers.put(q.getId(), params.get(key));
            }
        }
        int score = quizService.calculateScore(questions, answers);
        model.addAttribute("score", score);
        model.addAttribute("total", questions.size());
        model.addAttribute("username", session.getAttribute("user"));
        return "result";
    }
}
