
package com.example.quizapp.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    private static final String DEMO_USER = "admin";
    private static final String DEMO_PASS = "1234";

    @GetMapping("/")
    public String showLogin(Model model) {
        model.addAttribute("username", "");
        return "login";
    }

    @PostMapping("/login")
    public String doLogin(@RequestParam String username, @RequestParam String password, HttpSession session, Model model) {
        if (DEMO_USER.equals(username) && DEMO_PASS.equals(password)) {
            session.setAttribute("user", username);
            return "redirect:/home";
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "login";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @GetMapping("/home")
    public String home(HttpSession session) {
        if (session.getAttribute("user") == null) return "redirect:/";
        return "index";
    }
}
